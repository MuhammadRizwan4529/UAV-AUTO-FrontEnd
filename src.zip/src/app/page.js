"use client";

import React from "react";
import { Button } from "../components/ui/button";
const page = () => {
  return (
    <div className="bg-black">
      <Button variant="outline">Hello</Button>
    </div>
  );
};

export default page;
