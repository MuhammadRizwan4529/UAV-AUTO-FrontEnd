import React from "react";

const page = () => {
  return <div>Drones</div>;
};

export default page;
