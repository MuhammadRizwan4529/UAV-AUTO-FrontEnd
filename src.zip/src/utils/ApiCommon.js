"use client";
import axiosInstance from "./Axios";

export const ApiCommon = async (
  METHOD,
  URL,
  ERROR_MESSAGE = "Error making request",
  DATA = null
) => {
  try {
    switch (METHOD) {
      case "post": {
        const response = await axiosInstance.post(URL, DATA);
        return response.data;
      }
      case "getAll": {
        const response = await axiosInstance.get(URL);
        return response.data;
      }
      default: {
        console.log("Enter a valid method");
        return null;
      }
    }
  } catch (error) {
    console.log(ERROR_MESSAGE);
    console.log(error);
  }
};
