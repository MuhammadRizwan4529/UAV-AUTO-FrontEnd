"use client";
import { configureStore } from "@reduxjs/toolkit";
import stationReducer from "./Reducers/stationsSlice";

export const store = configureStore({
  reducer: {
    station: stationReducer,
  },
});
